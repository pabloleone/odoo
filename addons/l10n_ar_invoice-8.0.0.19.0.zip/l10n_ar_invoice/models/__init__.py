# -*- coding: utf-8 -*-
##############################################################################
# For copyright and license notices, see __openerp__.py file in module root
# directory
##############################################################################
from . import account
from . import afip
from . import partner
from . import country
from . import currency
from . import company
from . import invoice_line
from . import invoice
from . import product_uom
from . import account_chart_wizard
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
