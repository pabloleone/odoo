# -*- coding: utf-8 -*-

from openerp.openupgrade import openupgrade


@openupgrade.migrate()
def migrate(cr, version):
    pass
